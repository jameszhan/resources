struct fileps
	{
	char *buff, *bptr;
	int nchars, bsize;
	char eoferr, wrflag;
	};
extern struct fileps IEH3fpts[10];
