IEHzap(s)
{
write(2,s,6);
write(2,": argument count wrong\n",23);
write(2,"That's all, folks\n",18);
exit();
}
