double d_sin(x)
double *x;
{
double sin();
return( sin(*x) );
}
