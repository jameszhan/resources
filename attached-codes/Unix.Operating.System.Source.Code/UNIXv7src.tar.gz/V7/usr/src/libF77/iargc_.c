long int iargc_()
{
extern int xargc;
return ( xargc - 1 );
}
