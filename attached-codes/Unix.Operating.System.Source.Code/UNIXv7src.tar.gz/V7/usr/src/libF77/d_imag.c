#include "complex"

double d_imag(z)
dcomplex *z;
{
return(z->dimag);
}
