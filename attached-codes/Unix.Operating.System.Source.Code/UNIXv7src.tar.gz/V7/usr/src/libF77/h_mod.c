short h_mod(a,b)
short *a, *b;
{
return( *a % *b);
}
