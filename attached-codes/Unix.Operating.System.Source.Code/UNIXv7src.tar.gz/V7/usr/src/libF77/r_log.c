double r_log(x)
float *x;
{
double log();
return( log(*x) );
}
