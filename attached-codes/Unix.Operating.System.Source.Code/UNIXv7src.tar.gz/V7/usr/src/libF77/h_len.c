short h_len(s, n)
char *s;
long int n;
{
return(n);
}
