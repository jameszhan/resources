double d_int(x)
double *x;
{
return( (long int) (*x) );
}
