double d_sinh(x)
double *x;
{
double sinh();
return( sinh(*x) );
}
